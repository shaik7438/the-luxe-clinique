# Image credits

Photography below is from [Unsplash](https://unsplash.com) under the
[Unsplash License](https://unsplash.com/license): free to use for commercial
and non-commercial purposes, no permission or attribution required (credit is
given here as good practice). People shown are models, **not** clients or staff
of The LUXE Clinique; every such image carries an "Illustrative image" label on
the site. Images were resized, re-encoded to WebP and lightly colour-graded.

| Site slot | Unsplash photo |
|---|---|
| `home-hero` | https://unsplash.com/photos/woman-with-green-eyes-and-green-eyes-or6-NuAsC3w |
| `home-editorial` | https://unsplash.com/photos/a-woman-is-laying-down-with-her-eyes-closed-MGKzomg0Dts |
| `home-consultation` | https://unsplash.com/photos/a-woman-getting-a-facial-massage-at-a-spa-BJ7i-96glwM |
| `cat-skin` | https://unsplash.com/photos/beautician-applying-facial-mask-to-womans-face-2OVrIfOXDDY |
| `cat-injectables` | https://unsplash.com/photos/womans-face-with-eyes-closed-o5C-KDbZHww |
| `cat-pigmentation` | https://unsplash.com/photos/skincare-serum-bottle-and-dropper-on-a-pink-surface-BlcA2-o-7IM |
| `cat-hair` | https://unsplash.com/photos/smiling-woman-in-brown-top-holding-hairs-O-sNTavXbmE |
| `cat-dermatology` | https://unsplash.com/photos/hand-with-white-liquid-on-pink-y_CSTKJ0bEs |
| `cat-procedures` | https://unsplash.com/photos/white-powder-on-clear-glass-jar-beside-silver-scissors-Qxr2KdrMh5w |
| `patient-info` | https://unsplash.com/photos/a-blue-vase-with-pink-flowers-next-to-a-cup-and-saucer-G_snb4RSPlU |
| `treatment-lip-fillers` | https://unsplash.com/photos/a-close-up-of-a-womans-lips-and-nose-iVGmPVoi8Rk |
| `treatment-skin-boosters` | https://unsplash.com/photos/person-applying-serum-with-pink-nails-7LAbLSKbkaQ |
| `treatment-chemical-peels` | https://unsplash.com/photos/woman-receiving-facial-mask-treatment-at-spa-Pe9IXUuC6QU |

The 3D render (`cat-laser`) was created for this
project with three.js and carry no third-party rights.
