export const generalFaqs = [
  {
    q: "Do I need a consultation before any treatment?",
    a: "Yes. A clinician first assesses your concern, medical history and expectations, then discusses suitable options, risks, limitations, alternatives and aftercare. Some people are advised that a treatment isn't suitable.",
  },
  {
    q: "Can you tell me which treatment I need from this website?",
    a: "No. The information here is general and educational. Recommendations can only be made after an individual assessment.",
  },
  {
    q: "Are results guaranteed?",
    a: "No medical or aesthetic treatment can guarantee a result. Responses vary between individuals, and your clinician will explain what is realistic for you.",
  },
  {
    q: "What should I bring to my appointment?",
    a: "A list of your medicines and supplements, any relevant medical reports, details of previous skin or aesthetic treatments, and the products you use on your skin.",
  },
  {
    q: "Where is the clinic?",
    a: "103, Rajdhani Enclave, Preet Vihar, New Delhi 110092, near Preet Vihar Metro Station (Gate No. 3). Please check the route before visiting and call ahead about parking.",
  },
  {
    q: "Can I send medical questions through the enquiry form?",
    a: "Please use the form for appointment and administrative requests only, and avoid including detailed health information. For urgent medical concerns, contact emergency services or a doctor directly.",
  },
];
