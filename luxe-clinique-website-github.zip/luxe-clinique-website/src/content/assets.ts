/**
 * Visual asset manifest. Each entry is a slot in the site. Drop a file named
 * `<id>.webp` (or .jpg/.png/.avif) into /public/images and it is used
 * automatically at build time; until then an editorial beauty art plate renders.
 *
 * Sources
 *  • "illustrative" — licensed stock photography (Unsplash licence, see
 *    docs/IMAGE_CREDITS.md), 3D renders, or AI imagery (docs/AI_IMAGE_PROMPTS.md).
 *    Shown with a small "Illustrative image" label and never presented as the
 *    clinic's own clients, staff, results or premises.
 *  • "clinic-photo" — must be a genuine photograph of the clinic, its staff or
 *    its products (AI imagery would misrepresent the business here).
 */
export type AssetSource = "clinic-photo" | "illustrative" | "educational-render";

export interface AssetSlot {
  id: string;
  location: string;
  subject: string;
  alt: string;
  source: AssetSource;
  crops: { desktop: string; mobile: string };
  motif: "laser" | "skin" | "face" | "hair" | "room" | "consult" | "product" | "map" | "drop";
}

const AI_45 = { desktop: "4:5, 1600×2000", mobile: "4:5, 1600×2000" };

export const assets: AssetSlot[] = [
  /* ── AI-generated (illustrative) ── */
  { id: "home-hero", location: "Home · hero (arch frame)", subject: "Editorial beauty portrait — serene South Asian woman, eyes closed, dewy skin, blush backdrop (prompt H1).", alt: "Illustrative beauty portrait of a woman with glowing skin in soft light", source: "illustrative", crops: AI_45, motif: "face" },
  { id: "home-editorial", location: "Home · philosophy (arch frame)", subject: "Hands applying serum to the cheek, soft window light (prompt H2).", alt: "Illustrative image of hands gently applying serum to the cheek", source: "illustrative", crops: AI_45, motif: "face" },
  { id: "home-consultation", location: "Home · your journey", subject: "Relaxed consultation in a beauty lounge, faces softly out of frame (prompt H3).", alt: "Illustrative image of a relaxed beauty consultation over tea", source: "illustrative", crops: { desktop: "3:2, 1800×1200", mobile: "3:2, 1800×1200" }, motif: "consult" },
  { id: "cat-skin", location: "Treatments · Facials & glow", subject: "Luxury facial, hydrating mask, towels and petals (prompt C1).", alt: "Illustrative image of a relaxing hydrating facial", source: "illustrative", crops: AI_45, motif: "skin" },
  { id: "cat-injectables", location: "Treatments · Lips, lines & contours", subject: "Elegant side profile, natural lips and jawline, warm light (prompt C2).", alt: "Illustrative side profile of a woman in warm natural light", source: "illustrative", crops: AI_45, motif: "face" },
  { id: "cat-laser", location: "Treatments · Laser & light", subject: "Smooth legs/skin in soft light with a sleek white device beside (prompt C3).", alt: "Illustrative image of smooth skin in soft light beside a sleek white device", source: "illustrative", crops: AI_45, motif: "laser" },
  { id: "cat-pigmentation", location: "Treatments · Tone & radiance", subject: "Serum dropper above luminous cheek skin, macro (prompt C4).", alt: "Illustrative close-up of a serum dropper above glowing skin", source: "illustrative", crops: AI_45, motif: "drop" },
  { id: "cat-hair", location: "Treatments · Hair & scalp", subject: "Glossy dark hair in motion, back view (prompt C5).", alt: "Illustrative image of glossy dark hair in soft light", source: "illustrative", crops: AI_45, motif: "hair" },
  { id: "cat-dermatology", location: "Treatments · Skin health", subject: "Moisturiser on the back of a hand, botanicals (prompt C6).", alt: "Illustrative image of moisturiser being smoothed onto the skin", source: "illustrative", crops: AI_45, motif: "skin" },
  { id: "cat-procedures", location: "Treatments · Finishing touches", subject: "Brow artistry tools on marble with flowers (prompt C7).", alt: "Illustrative still life of brow artistry tools on marble", source: "illustrative", crops: AI_45, motif: "product" },
  { id: "patient-info", location: "Patient information", subject: "Notebook, pen and tea beside flowers on marble (prompt C8).", alt: "Illustrative still life of a notebook and tea beside flowers", source: "illustrative", crops: { desktop: "3:2, 1800×1200", mobile: "3:2, 1800×1200" }, motif: "consult" },

  /* ── Genuine clinic photography only ── */
  { id: "home-clinic-interior", location: "Home · the space", subject: "REAL PHOTO ONLY: the clinic's lounge or suite, styled with flowers, no people.", alt: "The softly lit lounge at The LUXE Clinique", source: "clinic-photo", crops: { desktop: "4:5, 1200×1500", mobile: "4:3, 900×675" }, motif: "room" },
  { id: "about-team", location: "About · the people", subject: "REAL PHOTO ONLY: verified clinician(s), with consent.", alt: "Clinician at The LUXE Clinique (name and registration to be confirmed)", source: "clinic-photo", crops: { desktop: "4:5, 1200×1500", mobile: "1:1, 900×900" }, motif: "face" },
  { id: "about-room", location: "About · the space", subject: "REAL PHOTO ONLY: treatment suite with the clinic's own devices.", alt: "A softly lit treatment suite at The LUXE Clinique", source: "clinic-photo", crops: { desktop: "16:9, 1920×1080", mobile: "4:3, 900×675" }, motif: "room" },
  { id: "products", location: "About · products", subject: "REAL PHOTO ONLY: the clinic's stocked skincare (ZO Skin Health, Obagi, Heliocare).", alt: "Skincare and sun-protection products available at the clinic", source: "clinic-photo", crops: { desktop: "3:2, 1500×1000", mobile: "1:1, 900×900" }, motif: "product" },
  { id: "contact-exterior", location: "Contact · find us", subject: "REAL PHOTO ONLY: entrance at 103 Rajdhani Enclave with signage.", alt: "Entrance to The LUXE Clinique at Rajdhani Enclave, Preet Vihar", source: "clinic-photo", crops: { desktop: "3:2, 1500×1000", mobile: "4:3, 900×675" }, motif: "map" },
];

export const assetById = (id: string) => assets.find((a) => a.id === id);
export const isIllustrative = (id: string) => assetById(id)?.source === "illustrative";

export const categoryImage: Record<string, string> = {
  laser: "cat-laser",
  injectables: "cat-injectables",
  skin: "cat-skin",
  pigmentation: "cat-pigmentation",
  hair: "cat-hair",
  dermatology: "cat-dermatology",
  procedures: "cat-procedures",
};
