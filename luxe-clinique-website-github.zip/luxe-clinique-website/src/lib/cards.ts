import { assetById, categoryImage } from "@/content/assets";
import { categories, type Treatment } from "@/content/treatments";
import type { TreatmentCardData } from "@/components/ui/GlassTreatmentCard";
import { resolveImage } from "./images";

/**
 * Image lookup order: /public/images/treatment-<slug>.* → category slot → art plate.
 * Per-treatment images are AI-generated illustrative images (docs/AI_IMAGE_PROMPTS.md).
 */
export function treatmentImage(t: Treatment) {
  const own = resolveImage(`treatment-${t.slug}`);
  const slot = assetById(categoryImage[t.category])!;
  const src = own ?? resolveImage(slot.id);
  return {
    src,
    alt: own ? `Illustrative image for ${t.name}` : slot.alt,
    motif: slot.motif,
    illustrative: !!src && (own ? true : slot.source === "illustrative"),
  };
}

export function toCard(t: Treatment): TreatmentCardData {
  const img = treatmentImage(t);
  return {
    slug: t.slug,
    name: t.name,
    summary: t.summary,
    categoryLabel: categories[t.category].label,
    hasModule: !!t.module,
    image: img.src,
    imageAlt: img.alt,
    motif: img.motif,
    illustrative: img.illustrative,
  };
}
