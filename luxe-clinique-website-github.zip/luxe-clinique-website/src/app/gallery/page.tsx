import { Info } from "lucide-react";
import { slotImage } from "@/lib/images";
import SkinIllustration from "@/components/education/SkinIllustration";
import ClinicImage from "@/components/media/ClinicImage";
import { AnimatedSection, Reveal } from "@/components/motion/AnimatedSection";
import HeroPoster from "@/components/three/HeroPoster";
import ParallaxImage from "@/components/motion/ParallaxImage";
import { ConsultationCTA, PageHero, SectionHeading } from "@/components/ui/blocks";
import { assets } from "@/content/assets";
import { modules } from "@/content/education";
import { pageMeta } from "@/lib/seo";

export const metadata = pageMeta({
  title: "Gallery — Clinic & Educational Artwork",
  description: "Photographs of The LUXE Clinique and clearly labelled educational illustrations of skin anatomy and treatment principles.",
  path: "/gallery",
});

export default function GalleryPage() {
  const clinic = assets.filter((a) => a.source === "clinic-photo");
  const mood = assets
    .filter((a) => a.source === "illustrative")
    .map((a) => ({ slot: a, img: slotImage(a.id) }))
    .filter((m): m is { slot: (typeof assets)[number]; img: NonNullable<ReturnType<typeof slotImage>> } => !!m.img);
  const renders = Object.values(modules).flatMap((m) => m.steps.map((s, i) => ({ key: `${m.id}-${i}`, module: m.title, step: s.title, state: s.state })));

  return (
    <>
      <PageHero
        image={slotImage("cat-hair")}
        eyebrow="Gallery"
        title="Inside"
        intro="Genuine clinic photography and clearly identified educational artwork. Patient before-and-after images are not shown here."
        crumbs={[{ href: "/gallery", label: "Gallery" }]}
      >
        <nav aria-label="Gallery sections" className="mt-8 flex flex-wrap gap-2">
          <a href="#clinic" className="btn btn-glass !min-h-10 !py-2 text-sm">Clinic</a>
          <a href="#mood" className="btn btn-glass !min-h-10 !py-2 text-sm">Mood</a>
          <a href="#educational" className="btn btn-glass !min-h-10 !py-2 text-sm">Educational renders</a>
        </nav>
      </PageHero>

      <section id="clinic" className="container-luxe scroll-mt-28 pb-16" aria-labelledby="clinic-h">
        <SectionHeading id="clinic-h" eyebrow="Clinic photography" title="Spaces and facilities" />
        <AnimatedSection as="ul" className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {clinic.map((a) => (
            <Reveal as="li" key={a.id}>
              <figure className="glass group overflow-hidden">
                <ClinicImage id={a.id} className="aspect-[4/3] w-full" sizes="(min-width:1024px) 33vw, 100vw" />
                <figcaption className="p-4 text-[14px] text-charcoal">{a.alt}</figcaption>
              </figure>
            </Reveal>
          ))}
        </AnimatedSection>
        <p className="mt-6 flex gap-2 text-[13.5px] text-muted">
          <Info size={16} className="mt-0.5 shrink-0 text-burgundy" aria-hidden />
          Clinic photographs are being commissioned. Where a branded plate appears, the genuine photograph has not yet been supplied.
        </p>
      </section>

      {mood.length > 0 && (
        <section id="mood" className="container-luxe scroll-mt-28 pb-16" aria-labelledby="mood-h">
          <SectionHeading id="mood-h" eyebrow="Mood & inspiration" title="The feeling of *LUXE*" intro="Illustrative imagery that sets the tone of our space and treatments. These are not clients or results." />
          <div className="mt-10 columns-1 gap-5 sm:columns-2 lg:columns-3 [&>*]:mb-5">
            {mood.map(({ slot, img }, i) => (
              <figure key={slot.id} className="break-inside-avoid">
                <ParallaxImage
                  src={img.src}
                  alt={img.alt}
                  amount={6}
                  illustrative
                  sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw"
                  className={`w-full rounded-[26px] ${["aspect-[4/5]", "aspect-square", "aspect-[3/4]"][i % 3]} ${i % 4 === 1 ? "rounded-t-full" : ""}`}
                />
                <figcaption className="mt-2 px-1 text-[13px] text-muted">{slot.location.split("·").pop()?.trim()}</figcaption>
              </figure>
            ))}
          </div>
        </section>
      )}

      <section id="educational" className="container-luxe scroll-mt-28 pb-16" aria-labelledby="edu-h">
        <SectionHeading id="edu-h" eyebrow="Educational renders" title="Illustrations used in our guides" intro="Conceptual artwork, not to scale. These are illustrations — not photographs of patients, and not representations of results." />
        <AnimatedSection as="ul" className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <Reveal as="li">
            <figure className="glass overflow-hidden">
              <HeroPoster className="aspect-[4/3] w-full" />
              <figcaption className="p-4">
                <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-rose-ink">Educational render · stylised</p>
                <p className="mt-1 text-[14px] text-charcoal">Laser hair reduction appointment set-up, with protective eyewear</p>
              </figcaption>
            </figure>
          </Reveal>
          {renders.map((r) => (
            <Reveal as="li" key={r.key}>
              <figure className="glass overflow-hidden">
                <div className="bg-gradient-to-b from-[#FBF6F4] to-[#F1E6E3] p-3">
                  <SkinIllustration state={r.state} title={`${r.module}: ${r.step}`} className="aspect-[640/420] w-full" />
                </div>
                <figcaption className="p-4">
                  <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-rose-ink">Educational render · {r.module}</p>
                  <p className="mt-1 text-[14px] text-charcoal">{r.step}</p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </AnimatedSection>
      </section>

      <ConsultationCTA />
    </>
  );
}
