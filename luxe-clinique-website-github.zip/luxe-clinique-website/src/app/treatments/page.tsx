import { Suspense } from "react";
import { slotImage } from "@/lib/images";
import TreatmentDirectory, { type DirectoryItem } from "@/components/treatments/TreatmentDirectory";
import { ConsultationCTA, PageHero, ReviewNotice } from "@/components/ui/blocks";
import { categories, concernLabels, publishedTreatments, type CategoryId, type ConcernId } from "@/content/treatments";
import { toCard } from "@/lib/cards";
import { pageMeta } from "@/lib/seo";

export const metadata = pageMeta({
  title: "Treatments",
  description:
    "Browse skin, hair, laser, injectable and medical dermatology treatment information at The LUXE Clinique, with balanced guidance on suitability, risks and aftercare.",
  path: "/treatments",
});

export default function TreatmentsPage() {
  const items: DirectoryItem[] = publishedTreatments.map((t) => ({
    ...toCard(t),
    category: t.category,
    concerns: t.concerns,
    keywords: [t.summary, ...t.intendedFor, ...t.concerns.map((c) => concernLabels[c])].join(" ").toLowerCase(),
  }));
  const usedConcerns = new Set(publishedTreatments.flatMap((t) => t.concerns));

  return (
    <>
      <PageHero
        image={slotImage("cat-skin")}
        eyebrow="The treatment menu"
        title="Treatments,"
        accent="tailored to you"
        intro="Facials, injectables, laser, peels and more — each with a full guide to how it works, who it suits, preparation and aftercare. Your plan is always confirmed at consultation."
        crumbs={[{ href: "/treatments", label: "Treatments" }]}
      />
      <section className="container-luxe pb-20">
        <Suspense fallback={<div className="glass h-40 animate-pulse" />}>
          <TreatmentDirectory
            items={items}
            categories={(Object.keys(categories) as CategoryId[]).map((id) => ({ id, label: categories[id].label }))}
            concerns={(Object.keys(concernLabels) as ConcernId[]).filter((c) => usedConcerns.has(c)).map((id) => ({ id, label: concernLabels[id] }))}
          />
        </Suspense>
        <ReviewNotice className="mt-12" />
      </section>
      <ConsultationCTA />
    </>
  );
}
